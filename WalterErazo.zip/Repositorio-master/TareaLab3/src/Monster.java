
public interface Monster {

    public String attack();
    
}