public class FireMoster implements Monster{
    private String name;
    public FireMoster(String name){
        this.name= name;
    }
    public String attack() {
        return "I�m: "+name+ " and i will attack with: Dragon Claw";
    } 
}