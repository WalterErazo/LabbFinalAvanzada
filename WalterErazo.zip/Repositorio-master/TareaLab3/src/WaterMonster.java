public class WaterMonster implements Monster{
    private String name;
    public WaterMonster(String name){
        this.name= name;
    }
    public String attack() {
        return "I�m: "+name+ " and i will attack with: Water Gun";
    } 
}