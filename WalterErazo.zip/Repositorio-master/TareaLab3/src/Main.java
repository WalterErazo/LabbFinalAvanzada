
public class Main {
	public static void main(String[] args) {
		Monster m1,m2,m3;
        m1= new WaterMonster("Squirtle ");
        System.out.println(m1.attack());
        m2= new StoneMonster("Onix  ");
        System.out.println(m2.attack());
        m3= new FireMoster("Charizard  ");
        System.out.println(m3.attack());

	}

}
