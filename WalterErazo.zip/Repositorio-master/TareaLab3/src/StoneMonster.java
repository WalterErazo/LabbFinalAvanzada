public class StoneMonster implements Monster{
    private String name;
    public StoneMonster(String name){
        this.name= name;
    }
    public String attack() {
        return "I�m: "+name+ " and i will attack with: Rock Throw";
    } 
}