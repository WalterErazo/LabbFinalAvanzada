#include "ESTPila.h"

#ifndef PRO2_H_
#define PRO2_H_

class Pro2 {
public:
	Pro2();
	virtual ~Pro2();
};

#endif /* PRO2_H_ */
