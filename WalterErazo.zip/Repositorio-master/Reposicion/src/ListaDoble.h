#ifndef LISTADOBLE_H_
#define LISTADOBLE_H_

struct node;
void add(int x);
void showForward(node* head);
void showReverse(node* tail);

#endif /* LISTADOBLE_H_ */
