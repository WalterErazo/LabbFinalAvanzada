
#ifndef DINPILA_H_
#define DINPILA_H_

void ingresar(int x);
void sacar ();
#endif /* DINPILA_H_ */
