#include <iostream>
using namespace std;
#include "DinPila.h"

struct pilas
{
int d;
pilas *a;
}*c,*b;

void ingresar (int x)
{
 if(!c)
 {
 c=new(pilas);
 c->d=x;
 c->a=NULL;
 return;
 }
 b=new(pilas);
 b->d=x;
 b->a=c;
 c=b;
}

void sacar(void)
{
 if(!c)
 {
 cout<<"No hay elementos!!"<<endl;
 return;
 }

 b=new(pilas);
 b=c;
 cout<<"Elemento eliminado: " <<b->d<<endl;
 c=b->a;
 delete(b);

}
