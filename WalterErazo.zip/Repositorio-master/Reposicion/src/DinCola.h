#ifndef DINCOLA_H_
#define DINCOLA_H_

void enqueue (int dat);
void dequeue ();
void listar ();

#endif /* DINCOLA_H_ */
