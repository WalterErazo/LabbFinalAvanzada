#include <iostream>
using namespace std;

#include "ListaSimple.h"
#include "ListaDoble.h"
#include "ListaCircular.h"
#include "DinCola.h"
#include "DinPila.h"
#include "ESTPila.h"
#include "ESTCola.h"

int main() {
	//ejemplo de lista
	/*LSinsertar(1);
	LSinsertar(2);
	LSinsertar(3);
	LSborrar();
	LSmostar();*/

	//ejemplo lista doble
	/*add(5);
	add(2);
	add(8);
	add(4);
	showForward(head);*/

	//ejemplo lista circular
	/*LISTACIRCULAR_H_::add(1);
	LISTACIRCULAR_H_::add(2);
	LISTACIRCULAR_H_::add(3);
	LISTACIRCULAR_H_::show();*/

	//ejemplo pila dinamica
	/*ingresar(1);
	ingresar(2);
	ingresar(3);
	sacar ();
	sacar ();*/

	//ejemplo cola dinamica
	/*enqueue(1);
	enqueue(2);
	enqueue(3);
	enqueue(4);
	enqueue(5);
	enqueue(6);
	listar();
	dequeue();
	listar();*/

	//ejemplo pila estatica
	/*Stack s;
	s.put(1);
	s.put(2);*/


	//ejemplo cola estatica
	/*Queue q;
	q.put(1);
	q.put(2);
	q.put(3);
	q.put(4);
	cout<<"Items = "<< q.size()<< endl;
	cout<<q.get()<<" ";
	cout<<q.get()<<" ";*/

	return 0;
}
