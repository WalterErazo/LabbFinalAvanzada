#include "ESTPila.h"
#include <iostream>
using namespace std;

int Stack::size()
{
	return items;

}

int Stack::empty(){
	return items ==0;
}

int Stack::put(char d)
{
	if( sp >=0){
		pila[sp]= d;
		sp--;
		items++;
	}
	return d;
}
int Stack::get()
{
	if(! empty()){
		sp++;
		items--;
	}
	return pila[sp];
}
