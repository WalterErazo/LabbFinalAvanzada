#include<iostream>
using namespace std;
#include "ListaCircular.h"

/*
 * Node Declaration
 */
struct CLnode
{
    int info;
    struct CLnode *next;
}*CLlast;

/*
 * Class Declaration
 */
class circular_llist
{
    public:
        void add(int value);
        void remove(int value);
        void show();
        circular_llist()
        {
            CLlast = NULL;
        }
};


void circular_llist::add(int value)
{
    struct CLnode *temp;
    temp = new(struct CLnode);
    temp->info = value;
    if (CLlast == NULL)
    {
        CLlast = temp;
        temp->next = CLlast;
    }else{
        temp->next = CLlast->next;
        CLlast->next = temp;
    }

}


/*
 * Deletion of element from the list
 */
void circular_llist::remove(int value)
{
    struct CLnode *temp, *s;
    s = CLlast->next;
      /* If List has only one element*/
    if (CLlast->next == CLlast && CLlast->info == value)
    {
        temp = CLlast;
        CLlast = NULL;
        free(temp);
        return;
    }
    if (s->info == value)  /*First Element Deletion*/
    {
        temp = s;
        CLlast->next = s->next;
        free(temp);
        return;
    }
    while (s->next != CLlast)
    {
        /*Deletion of Element in between*/
        if (s->next->info == value)
        {
            temp = s->next;
            s->next = temp->next;
            free(temp);
            cout<<"Element "<<value;
            cout<<" deleted from the list"<<endl;
            return;
        }
        s = s->next;
    }
    /*Deletion of last element*/
    if (s->next->info == value)
    {
        temp = s->next;
        s->next = CLlast->next;
        free(temp);
        CLlast = s;
        return;
    }
    cout<<"Element "<<value<<" not found in the list"<<endl;
}


/*
 * Display Circular Link List
 */
void circular_llist::show()
{
    struct CLnode *s;
    if (CLlast == NULL)
    {
        cout<<"List is empty, nothing to display"<<endl;
        return;
    }
    s = CLlast->next;
    cout<<"Circular Link List: "<<endl;
    while (s != CLlast)
    {
        cout<<s->info<<"->";
        s = s->next;
    }
    cout<<s->info<<endl;
}
