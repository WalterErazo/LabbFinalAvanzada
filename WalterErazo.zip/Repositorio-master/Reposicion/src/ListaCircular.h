#ifndef LISTACIRCULAR_H_
#define LISTACIRCULAR_H_

struct CLnode;
class circular_llist;
void add(int value);
void show();
void remove(int value);
#endif /* LISTACIRCULAR_H_ */
