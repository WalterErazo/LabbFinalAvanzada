#include "ListaSimple.h"
#include <iostream>
using namespace std;

struct dato{
	int i;
	dato *s;
}*a, *i,*p,*e;
int da;

void LSmostar(void)
{
    int cont=1;
    if(!i)
    {
        cout<<"\n\nNO HAY LISTA PARA MOSTRAR";

        return;
    }
    p=i;
    cout<<endl<<endl;
    while(p)
    {
        cout<<cont++<<" - Valor = "<<p->i<<endl;
        p=p->s;
    }
    cout<<"\n\nEso es todo";
}
int LSbuscar(int d)
 {
	 if (!i)
	 {
		 cout<<"No hay datos en la lista";
	 return(0);
	 }
	 p=i;
	 a=NULL;
	 while(p->s && p->i<d)
	 {
		 a=p;
		 p=p->s;
	 }
	 return(p->i==d?1:0);
 }
void LSinsertar(int dat)
{
    if(!i)
    {
        i=new(dato);
        i->s=NULL;
        i->i=dat;
        return;
    }
    if(LSbuscar(dat))
    {
        cout<<"\n\nDato existente";
        return;
    }
    e=new(dato);
    e->i=dat;
    if(p==i && p->s)
    {
        e->s=p;
        i=e;
        return;
    }
    if(p==i && !p->s)
    {
        if(p->i < e->i)
        {
            p->s=e;
            e->s=NULL;
        }
        else
        {
            e->s=p;
            i=e;
        }
        return;
    }
    if(p->s)
    {
        a->s=e;
        e->s=p;
        return;
    }
    if(e->i > p->i)
    {
        e->s=NULL;
        p->s=e;
    }
    else
    {
        a->s=e;
        e->s=p;
    }
}



void LSborrar(void){
	cout << "ingrese dato a eliminar: "<<endl;
	cin>> da;
	if(LSbuscar(da)){
		if(a){
			a->s=p->s;
		}else{
			i=p->s;
		}
		delete(p);
		cout<< "dato eliminado"<<endl;
	}else{
		cout<< "dato no encontrado"<<endl;
	}
}

