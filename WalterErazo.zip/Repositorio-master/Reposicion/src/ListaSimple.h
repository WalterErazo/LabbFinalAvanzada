#ifndef LISTASIMPLE_H_
#define LISTASIMPLE_H_

int LSbuscar(int d);
void LSinsertar(int dat);
void LSmostar();
void LSborrar(void);

#endif
