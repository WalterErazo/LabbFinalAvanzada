#include <iostream>
using namespace std;
#include "DinCola.h"

struct datos {
    int dato;
    datos *s;
}*p1,*aux,*u;
void enqueue (int dat)
{
    aux=new(datos);
    aux->dato=dat;
    if(u)
    {
        u->s=aux;
        aux->s=NULL;
        u=aux;
    }
    else
    {
        p1=u=aux;
    }
}
void dequeue()
{
    if(p1)
    {
        aux=p1;
        cout<<"\nElimino a " <<p1->dato<<endl;
        p1=aux->s;
        delete(aux);
    }
    else
    {
        cout<<"\n No hay datos"<<endl;
    }
}

void listar()
{
    int i=0;
    if(!u)
    {
        cout<<"\n No hay datos en la cola"<<endl;
        return;
    }else{
        aux=p1;
        while(aux)
        {
            cout<<++i<<" - "<<aux->dato<<endl;
            aux=aux->s;
        }
    }
}
