
#include <iostream>
using namespace std;
#include "ListaDoble.h"
struct node{
	int data;
	node* next;
	node* prev;
};
node* head;
node* tail;
node* n;

void add(int x){
    if(!n){
        n =   new node;
        n -> data = x;
        n-> prev = NULL;
        head = n;
        tail = n;
    }else{
        n = new node;
        n -> data =x;
        n->prev = tail;
        tail -> next = n;
        tail=n;
    }
}
void showForward(node* head)
{
    node* temp = head;
    while(temp != NULL){
        cout<<temp->data<<" -> ";
        temp = temp->next;
    }
    cout<<endl;
}

void showReverse(node* tail)
{
    node* temp = tail;
    while(temp != NULL){
        cout<<temp->data<<" -> ";
        temp = temp->prev;
    }
    cout<<endl;
}
