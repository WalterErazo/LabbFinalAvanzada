#ifndef ESTPILA_H_
#define ESTPILA_H_

class ESTPila {
public:
	ESTPila();
	virtual ~ESTPila();
};

#define STACK_SIZE 50  /* capacidad m�xima */
typedef int arreglopilaest[STACK_SIZE];
class Stack {
public:
    int sp;/* puntero de lectura/escritura */
    int items;/* n�mero de elementos en lista */
    int itemsize;/* tama�o del elemento */
    arreglopilaest pila;/* el arreglo */
    // constructor
    Stack(){
        sp= STACK_SIZE-1;
        items=0;
        itemsize=1;
    }
	~Stack(){};
    int size();
    int empty();
    int put(char d);
    int get();
};



#endif /* ESTPILA_H_ */
