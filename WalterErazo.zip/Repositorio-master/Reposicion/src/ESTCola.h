#ifndef ESTCOLA_H_
#define ESTCOLA_H_
class ESTCola {
public:
	ESTCola();
	virtual ~ESTCola();
};



#define MAX_SIZE 50  /* capacidad m�xima */
typedef int almacen[MAX_SIZE];

class Queue {
public:
    int cabeza;/* puntero de lectura   */
    int cola;/* puntero de escritura */
    int ITEMS;/* n�mero de elementos en la lista */
    int ITEMSIZE;/* tama�o de cada elemento */
    almacen alma;/* el almacen */
    Queue(){
        cabeza=0;
        cola=0;
        ITEMS =0;
        ITEMSIZE =1;
    }
	~Queue(){}
    int empty();
    int put(int d);
    int get();
    int size();

};


#endif /* ESTCOLA_H_ */
