public class Lab6 {
    public static void main(String[] args) {        
        PositionalList <String> myList = new LinkedPositionalList <>();
        Position <String> p0,p1,p2,p3,p4;

        p0 = myList.addFirst("g");
        p1 = myList.addAfter(p0,"f");
        p2 = myList.addAfter(p1,"b");
        p2 = myList.addAfter(p2,"c");
        p2 = myList.addAfter(p2,"d");
        p3 = p2;
        p4 = myList.addAfter(p3,"e");
        String p= null;
        do{
            try{
                Position<String> tempPosition = myList.first();
                p = myList.remove(tempPosition);
                System.out.println(p);
            }catch(Exception e){
                
            }
        }while(p != null);
    }    
}
