package gt.edu.url.nivelesAcceso.usuarios;
public abstract class Employee {
    public String name;//default
    private int hireYear;
    protected String country;
    /**
     * 
     * @return el año de contratacion 
     */
    public int gethireYear(){
        return hireYear;
    }
    /**
     * 
     * @param hireYear dato que fija que año de contratacion
     */   
    public void sethireYear(int hireYear){
        this.hireYear=hireYear;
    }
    /**
     
     * @return 
     */
    protected abstract double montlyPay();
    /**
     * 
     * @return 
     */
    protected abstract double annualPay();    
}
