package gt.edu.url.nivelesAcceso.usuarios;

/**
 *
 * @author walte
 */
    public abstract class SalarioEmployee extends Employee{
    int annualSalary;
    /**
     * constructor
     */
    public SalarioEmployee(){
        name ="Walter";
        sethireYear(1998);
       country ="Guatemala";
    }
   
    
    @Override
    protected double montlyPay() {
        return 1000.00;
    }
    protected abstract double annualPay();
    
}
