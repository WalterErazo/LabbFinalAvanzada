
import gt.edu.url.nivelesAcceso.usuarios.Employee;

public class Laboratorio7 {
    public static void main(String[] args) {
        
        
    }    
}
