# Laboratorio 7 
----------------

- Walter Osoy Veliz
- carne: 1126017

## Clases:
----------

- Employee
    - Clase abstracta 
- FullTime
    - calcula el total a pagar de un trabajador de tiempo completo 
- HourlyEmployee
- Manager
- PartTime
- SalarioEmployee
- Staff
