#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

struct Nodo{
	int dato;
	struct Nodo* siguiente;
};
int main() {
	struct Nodo* n= NULL;
	struct Nodo* aux = NULL;
	struct Nodo* inicio = NULL;

	for (int i = 0; i < 4; i++) {
		n=(struct Nodo*)malloc(sizeof(struct Nodo));
		n->dato=i*2;
		aux->siguiente=n;
		aux=aux->siguiente;
		n->siguiente=NULL;
	}
	aux=inicio;

	while(aux){
		cout<<" -> "<< aux->dato<<endl;
		aux=aux->siguiente;
	}

	return 0;
}