# Tarea numero 5 del laboratorio de porgramacion avanzada 

Author: Walter Osoy 
Carné: 1126017
## Metodos y Funsiones
### Listas enlazadas 
- Main:
  contine el codigo para realizar una lista de 4 nodos y depues lo imprime 
