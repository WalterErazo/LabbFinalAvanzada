package Lab8.Lab8;
import java.util.Scanner;

public class App 
{
    public static void main( String[] args )
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("ingrese la direccion del archivo que desea cargar");
        String ruta=sc.nextLine();
        DemoGraphviz demo = new DemoGraphviz();
        demo.createDemoFromDot(ruta);
    }
}
