
public class DemoRecursividad {
private int ejecucion;
private int resultado=1;
	public static void main(String[] args) {
		DemoRecursivo demoObj = new DemoRecursivo();
		int resultado = demoObj.calcularFactorial(5);
		System.out.println(resultado);

	}
	
}
