
public class Partido implements Reportero{
	
	public Partido() {
		
	}

	@Override
	public int calcularGanador(int a, int b) {
		// TODO Auto-generated method stub
		if(a>8 || b>8) {
			
		}
		return 0;
	}

	@Override
	public int calcularCampeon() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int recordarGanador(int game) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}