
public class Calculos implements Chudnovsky{
	private int x;
	
	public Calculos(int x) {
		// TODO Auto-generated constructor stub
		this.x=x;
	}
	
	/**
	 *calcula el factoria de un dato que entra como parametro 
	 *y lo calculo por recursividad 
	 * 
	 */
	public int factorial(int x) {
		if(x==0) {
			return 1;
		}else {
			return x * factorial(x-1);
		}		
	}
	
	//numerador
	/**
	 * 
	 * @return calcula las dos partes de la multiplicaci�n del numerador 
	 */
	public double numeradorf() {
		return numerador1()*numerador2();
	}
	public double numerador1() {		
		return factorial(6*x);
	}
	public double numerador2() {		
		return (545140134*x+13591409);
	}
	//denominador
	/**
	 * 
	 * @return Calcula las 3 partes de las multiplicaciones del denominador 
	 */
	public double deminadorf() {
		return denominador1()*denominador2()*denominador3();
	}
	public int denominador1() {		
		return factorial(3*x);
	}
	public double denominador2() {
		return Math.pow((double)factorial(x),3);
	}
	public double denominador3() {
		return Math.pow(-262537412640768000.0, x);
	}
	/**
	 * 
	 * @return retorna el resultado final
	 */
	public double result () {
		return numeradorf()/deminadorf();
	}
}
