public interface Chudnovsky {
	/**
	 * 
	 * @param x para calcular el factorial
	 * @return factorial de la variable x
	 */
	public int factorial(int x);
	
}
