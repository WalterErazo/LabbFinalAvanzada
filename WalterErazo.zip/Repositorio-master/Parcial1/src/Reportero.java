
public interface Reportero {
	public int calcularGanador(int a, int b);
	public int calcularCampeon();
	public int recordarGanador(int game);
}
