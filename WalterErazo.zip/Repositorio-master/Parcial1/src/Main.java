import java.util.Scanner;
public class Main {
	public static void main(String[] args) {		
		/**
		 * @author walte Osoy
		 * version 0.1 
		 * 
		 */
		//programa 1
		Calculos ej1 = new Calculos(3);
		System.out.println(ej1.result());

		//programa 2
		Reportero obj = new Partido();
		Scanner ReadLine = new Scanner (System.in);
		System.out.println("Ingrese el resultado del jugador A");
		int a = ReadLine.nextInt();
		System.out.println("Ingrese el resultado del jugador B");
		int b = ReadLine.nextInt();
		obj.calcularGanador(a, b);
		
	}

}
