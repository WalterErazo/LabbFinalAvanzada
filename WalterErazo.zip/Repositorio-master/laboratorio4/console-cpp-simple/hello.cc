// Simple Hello World
 
#include <iostream>
 int Sumar(int, int);
 int Restar(int, int);
 int Multiplicar(int, int);
 int Dividir(int, int);
 
 void psuma(int, int,int*);
 void presta(int, int,int*);
 void pmult(int, int,int*);
 void pdivi(int, int,int*);
 
int main()
{
  
  std::cout << "hola buenas tardes," << std::endl;
  //referencia
  double Resultado = Sumar(5, 7);
  std::cout << Resultado << std::endl;
  Resultado = Restar(10, 7);
  std::cout << Resultado << std::endl;
  Resultado = Multiplicar(5, 7);
  std::cout << Resultado << std::endl;
  Resultado = Dividir(15, 5);
  std::cout << Resultado << std::endl; 
  
  // punteros
  int puntRes = -1;
  psuma(8, 7, &puntRes);
  std::cout << "resultado es " << puntRes << std::endl;
  
  presta(8, 5, &puntRes);
  std::cout << "resultado es " << puntRes << std::endl;
  
  pmult(2, 2, &puntRes);
  std::cout << "resultado es " << puntRes << std::endl;
  
  pdivi(10, 5, &puntRes);
  std::cout << "resultado es " << puntRes << std::endl;

  
  return 0;
}


int Sumar(int a , int b){
     return a+b;
 }
 int Restar(int a , int b){
     return a-b;
 }
 int Multiplicar(int a , int b){
     return a*b;
 }
 int Dividir(int a , int b){
     return a/b;
 }
//punteros

void psuma(int a, int b, int* Resultado){
    *Resultado = a+b;
}
void presta(int a, int b, int* Resultado){
    *Resultado = a-b;
}
void pmult(int a, int b, int* Resultado){
    *Resultado = a*b;
}
void pdivi(int a, int b, int* Resultado){
    *Resultado = a/b;
}