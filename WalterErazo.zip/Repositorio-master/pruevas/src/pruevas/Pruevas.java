package pruevas;

import java.util.Arrays;

public class Pruevas {
	private int xy[] = new int[2];
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}
	public int[] getXy() {
		return xy;
	}
	public void setXy(int[] xy) {
		this.xy = xy;
	}
	@Override
	public String toString() {
		return "Pruevas [xy=" + Arrays.toString(xy) + "]";
	}
	
}
