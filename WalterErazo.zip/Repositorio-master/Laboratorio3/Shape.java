package org.eclipse.che.examples;

public interface Shape {
    public double getArea();
    public String toString();
}